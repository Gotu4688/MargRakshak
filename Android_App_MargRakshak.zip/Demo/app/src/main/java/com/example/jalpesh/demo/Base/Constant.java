package com.example.jalpesh.demo.Base;

/**
 * Created by Jalpesh on 12/25/2018.
 */

public class Constant {

    public static final String WEB_URL="http://192.168.43.9:81/";

    public static final String LOG_TAG="alltypeservices.in";
}
